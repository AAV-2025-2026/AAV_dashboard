#!/usr/bin/env python3
"""
AAV Web Dashboard Bridge (ROS 2 -> Web)
Runs on your PC (same LAN as Jetson).

Subscribes (defaults):
  /aav/stop_sign_detected      (std_msgs/Bool)
  /aav/stop_sign_confidence    (std_msgs/Float32)
  /aav/stop_sign_detections    (vision_msgs/Detection2DArray)
  /camera/cam1/image_raw       (sensor_msgs/Image)
  /camera/cam2/image_raw       (sensor_msgs/Image)

Serves:
  http://localhost:8080  (HTML)
  ws://localhost:9090    (JSON stream)

Overrides via env vars:
  AAV_DETECTED_TOPIC, AAV_CONF_TOPIC, AAV_DETS_TOPIC, AAV_CAM1_TOPIC, AAV_CAM2_TOPIC
  AAV_CAM_COMPRESSED=1 to subscribe to sensor_msgs/CompressedImage on the cam topics.
"""

import os
import json
import base64
import asyncio
import threading
import logging
import http.server

import websockets

import rclpy
from rclpy.node import Node

from std_msgs.msg import Bool, Float32
from vision_msgs.msg import Detection2DArray

from sensor_msgs.msg import Image
from cv_bridge import CvBridge

# Optional compressed support
try:
    from sensor_msgs.msg import CompressedImage
except Exception:
    CompressedImage = None

try:
    import cv2
except Exception as e:
    raise RuntimeError("opencv-python is required. Install with: pip3 install opencv-python") from e

HTTP_PORT = int(os.environ.get("AAV_HTTP_PORT", "8080"))
WS_PORT   = int(os.environ.get("AAV_WS_PORT", "9090"))
FPS       = float(os.environ.get("AAV_FPS", "15"))
JPEG_QUALITY = int(os.environ.get("AAV_JPEG_QUALITY", "60"))

TOPIC_DETECTED   = os.environ.get("AAV_DETECTED_TOPIC", "/aav/stop_sign_detected")
TOPIC_CONFIDENCE = os.environ.get("AAV_CONF_TOPIC", "/aav/stop_sign_confidence")
TOPIC_DETECTIONS = os.environ.get("AAV_DETS_TOPIC", "/aav/stop_sign_detections")
TOPIC_CAM1       = os.environ.get("AAV_CAM1_TOPIC", "/camera/cam1/image_raw")
TOPIC_CAM2       = os.environ.get("AAV_CAM2_TOPIC", "/camera/cam2/image_raw")
CAM_COMPRESSED   = os.environ.get("AAV_CAM_COMPRESSED", "0") in ("1", "true", "True", "yes", "YES")

logging.basicConfig(level=logging.INFO, format='[AAV] %(message)s')
log = logging.getLogger("aav_web_dashboard")

class SharedState:
    def __init__(self):
        self.lock = threading.Lock()
        self.detected = False
        self.confidence = 0.0
        self.detections = []
        self.cam1 = None
        self.cam2 = None
        self.clients = set()

state = SharedState()
bridge = CvBridge()

async def ws_handler(websocket):
    log.info(f"Browser connected: {websocket.remote_address}")
    with state.lock:
        state.clients.add(websocket)
    try:
        await websocket.wait_closed()
    finally:
        with state.lock:
            state.clients.discard(websocket)

async def broadcast_loop():
    interval = 1.0 / max(FPS, 1.0)
    while True:
        await asyncio.sleep(interval)
        with state.lock:
            if not state.clients:
                continue
            payload = json.dumps({
                "detected": state.detected,
                "confidence": round(float(state.confidence), 3),
                "detections": state.detections,
                "cam1": state.cam1,
                "cam2": state.cam2,
            })
            clients = list(state.clients)

        dead = set()
        for ws in clients:
            try:
                await ws.send(payload)
            except Exception:
                dead.add(ws)

        if dead:
            with state.lock:
                state.clients -= dead

async def start_ws_server():
    log.info(f"WebSocket: ws://0.0.0.0:{WS_PORT}")
    async with websockets.serve(ws_handler, "0.0.0.0", WS_PORT):
        await broadcast_loop()

class DashboardHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=os.getcwd(), **kwargs)

    def do_GET(self):
        if self.path == "/":
            self.path = "/aav_dashboard.html"
        super().do_GET()

    def log_message(self, *args):
        pass

def start_http_server():
    server = http.server.HTTPServer(("0.0.0.0", HTTP_PORT), DashboardHandler)
    log.info(f"Dashboard: http://localhost:{HTTP_PORT}")
    server.serve_forever()

class DashboardBridgeNode(Node):
    def __init__(self):
        super().__init__("aav_dashboard_bridge")

        self.create_subscription(Bool, TOPIC_DETECTED, self.cb_detected, 10)
        self.create_subscription(Float32, TOPIC_CONFIDENCE, self.cb_confidence, 10)
        self.create_subscription(Detection2DArray, TOPIC_DETECTIONS, self.cb_detections, 10)

        if CAM_COMPRESSED:
            if CompressedImage is None:
                raise RuntimeError("CompressedImage not available in this ROS install.")
            self.create_subscription(CompressedImage, TOPIC_CAM1, self.cb_cam1_compressed, 1)
            self.create_subscription(CompressedImage, TOPIC_CAM2, self.cb_cam2_compressed, 1)
            log.info("Camera mode: COMPRESSED")
        else:
            self.create_subscription(Image, TOPIC_CAM1, self.cb_cam1, 1)
            self.create_subscription(Image, TOPIC_CAM2, self.cb_cam2, 1)
            log.info("Camera mode: RAW Image")

        log.info("Subscribed topics:")
        log.info(f"  detected   : {TOPIC_DETECTED}")
        log.info(f"  confidence : {TOPIC_CONFIDENCE}")
        log.info(f"  detections : {TOPIC_DETECTIONS}")
        log.info(f"  cam1       : {TOPIC_CAM1}")
        log.info(f"  cam2       : {TOPIC_CAM2}")

    def cb_detected(self, msg: Bool):
        with state.lock:
            state.detected = bool(msg.data)

    def cb_confidence(self, msg: Float32):
        with state.lock:
            state.confidence = float(msg.data)

    def cb_detections(self, msg: Detection2DArray):
        dets = []
        for d in msg.detections:
            cx = float(d.bbox.center.position.x)
            cy = float(d.bbox.center.position.y)
            w  = float(d.bbox.size_x)
            h  = float(d.bbox.size_y)
            conf = 0.0
            if getattr(d, "results", None) and len(d.results) > 0 and getattr(d.results[0], "hypothesis", None):
                conf = float(d.results[0].hypothesis.score)
            dets.append({"x": cx - w/2.0, "y": cy - h/2.0, "w": w, "h": h, "conf": conf})
        with state.lock:
            state.detections = dets

    def cb_cam1(self, msg: Image):
        encoded = self._encode_from_image_msg(msg)
        if encoded:
            with state.lock:
                state.cam1 = encoded

    def cb_cam2(self, msg: Image):
        encoded = self._encode_from_image_msg(msg)
        if encoded:
            with state.lock:
                state.cam2 = encoded

    def cb_cam1_compressed(self, msg):
        encoded = self._encode_from_compressed_msg(msg)
        if encoded:
            with state.lock:
                state.cam1 = encoded

    def cb_cam2_compressed(self, msg):
        encoded = self._encode_from_compressed_msg(msg)
        if encoded:
            with state.lock:
                state.cam2 = encoded

    def _encode_from_image_msg(self, msg: Image):
        try:
            frame = bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
            ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
            if not ok:
                return None
            return base64.b64encode(buf).decode("utf-8")
        except Exception as e:
            self.get_logger().warning(f"RAW encode error: {e}")
            return None

    def _encode_from_compressed_msg(self, msg):
        try:
            import numpy as np
            arr = np.frombuffer(msg.data, dtype=np.uint8)
            frame = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            if frame is None:
                return None
            ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
            if not ok:
                return None
            return base64.b64encode(buf).decode("utf-8")
        except Exception as e:
            self.get_logger().warning(f"COMPRESSED decode/encode error: {e}")
            return None

def main():
    try:
        from ament_index_python.packages import get_package_share_directory
        share_dir = get_package_share_directory("aav_web_dashboard")
        os.chdir(share_dir)
    except Exception:
        pass

    threading.Thread(target=start_http_server, daemon=True).start()
    threading.Thread(target=lambda: asyncio.run(start_ws_server()), daemon=True).start()

    rclpy.init()
    node = DashboardBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        log.info("Shutting down")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
