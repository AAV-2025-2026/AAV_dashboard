#!/usr/bin/env bash
set -e

source /opt/ros/humble/setup.bash
if [ -f ~/ros2_ws/install/setup.bash ]; then
  source ~/ros2_ws/install/setup.bash
fi

export ROS_DOMAIN_ID=${ROS_DOMAIN_ID:-10}
export ROS_LOCALHOST_ONLY=${ROS_LOCALHOST_ONLY:-0}
export RMW_IMPLEMENTATION=${RMW_IMPLEMENTATION:-rmw_fastrtps_cpp}

echo "[AAV] ROS_DOMAIN_ID=$ROS_DOMAIN_ID"
echo "[AAV] ROS_LOCALHOST_ONLY=$ROS_LOCALHOST_ONLY"
echo "[AAV] RMW_IMPLEMENTATION=$RMW_IMPLEMENTATION"

echo "[AAV] Starting dashboard bridge..."
ros2 run aav_web_dashboard dashboard_bridge
