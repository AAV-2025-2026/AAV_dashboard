# AAV Web Dashboard (ROS 2 -> Web) — v0.2.0

## Defaults (matches your setup)
- /aav/stop_sign_detected (Bool)
- /aav/stop_sign_confidence (Float32)
- /aav/stop_sign_detections (Detection2DArray)
- /camera/cam1/image_raw (Image)
- /camera/cam2/image_raw (Image)

Serves:
- http://localhost:8080
- ws://localhost:9090

## One-time install (PC)
```bash
sudo apt update
sudo apt install -y ros-humble-cv-bridge
pip3 install websockets opencv-python numpy
```

## Build + run
```bash
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
# copy this folder (aav_web_dashboard) here

cd ~/ros2_ws
colcon build --symlink-install
source install/setup.bash

export ROS_DOMAIN_ID=10
export ROS_LOCALHOST_ONLY=0
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp

ros2 run aav_web_dashboard dashboard_bridge
```

Open: http://localhost:8080

## Overrides
```bash
export AAV_CAM1_TOPIC=/camera/cam1/image_raw
export AAV_CAM2_TOPIC=/camera/cam2/image_raw
```

Compressed cams:
```bash
export AAV_CAM1_TOPIC=/camera/cam1/image_raw/compressed
export AAV_CAM2_TOPIC=/camera/cam2/image_raw/compressed
export AAV_CAM_COMPRESSED=1
```
