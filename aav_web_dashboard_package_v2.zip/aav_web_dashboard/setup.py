from setuptools import setup

package_name = "aav_web_dashboard"

setup(
    name=package_name,
    version="0.2.0",
    packages=[package_name],
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
        ("share/" + package_name, ["aav_web_dashboard/aav_dashboard.html"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Raphaël",
    maintainer_email="raphael@example.com",
    description="ROS2 -> Web dashboard bridge (HTTP + WebSocket)",
    license="MIT",
    entry_points={
        "console_scripts": [
            "dashboard_bridge = aav_web_dashboard.dashboard_node:main",
        ],
    },
)
